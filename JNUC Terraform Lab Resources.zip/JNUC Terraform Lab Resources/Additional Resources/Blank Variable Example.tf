variable "<LABEL>" {
  type        = <TYPE> #string, number etc
  default     = "<DEFAULT_VALUE>" #Sets the default value for this variable.
  description = "<DESCRIPTION>" #A description of the variable’s purpose and the value it expects.
  sensitive   = <true|false> #Specifies if Terraform hides this value in CLI output.

}