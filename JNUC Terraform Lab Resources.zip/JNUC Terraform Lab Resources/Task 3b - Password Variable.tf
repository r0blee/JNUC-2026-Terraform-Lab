variable "account_password" {
  type        = string #string, number etc
  default     = "<DEFAULT_VALUE>" #Sets the default value for this variable.
  description = "This is the password for my Jamf Pro Auditor account" #A description of the variable’s purpose and the value it expects.
  sensitive   = <true|false> #Specifies if Terraform hides this value in CLI output.

}