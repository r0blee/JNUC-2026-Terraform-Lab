module "compliance" {
    source = "./modules/compliance"
    attendee_name = var.attendee_name
}

module "blueprints" {
    source = "./modules/blueprints"
    attendee_name = var.attendee_name
}