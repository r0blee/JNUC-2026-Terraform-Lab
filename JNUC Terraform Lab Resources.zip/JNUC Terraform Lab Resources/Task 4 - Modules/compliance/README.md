# JNUC 2026 - Terraform Module - Blueprints

This is a modularised terraform configuration containing a compliance benchmark for Jamf Pro. 

# Contents

## Provider

This module utilises the Jamf platform provider and is intended to inherit its credentials for this, from the root module. 

## Resources

There is one resource declared in this modules **main.tf** file. 
It's purpose it to configure a **CIS Level 1 Benchmark** configuration to monitor and enforce all CIS Level 1 rules but only for macOS 26 devices.

## Variables
There is one variables expected to be shared with the module from the root module. It is declared in **variables.tf** and is called **attendee_name**

## Data Sources

There is one data source declared in the main.tf file. The purpose of this data source is to read from Jamf Pro the attributes of the existing **All Managed Clients** group so that we can utilise its ID to scope our blueprint to. 




# How to use this module

In your root module you need to declare a **module** and point its source to the location of this folder. 

As per the variables subsection you will also need to add to this module block. For example:

module "compliance" {
  source = "./modules/compliance"
  attendee_name = var.attendee_name
}
