terraform {
required_providers {
jamfplatform = {
source = "jamf/jamfplatform"
}
}
}

data "jamfplatform_device_groups" "all_managed_clients" {
filter = [
{
selector = "name"
argument = "All Managed Clients"
},
{
join_with = "and"
selector  = "groupType"
argument  = "SMART"
}
]
}

data "jamfplatform_cbengine_rules" "cis_lvl1" {
baseline_id = "cis_lvl1"
}


resource "jamfplatform_cbengine_benchmark" "cis_lvl1" {
title              = "[${var.attendee_name}] CIS Level 1 Benchmark - macOS 26, All Rules"
description        = "Created by Terraform"
source_baseline_id = "cis_lvl1"
selected_os_versions = [
{ os_type = "MAC_OS", os_version = 26 },
]
rules = [
for r in data.jamfplatform_cbengine_rules.cis_lvl1.rules : {
id      = r.id
enabled = r.enabled
}
] # Multiple device groups can be targeted simultaneously.
target_device_groups = data.jamfplatform_device_groups.all_managed_clients.device_groups[*].id
enforcement_mode     = "MONITOR_AND_ENFORCE"
}
