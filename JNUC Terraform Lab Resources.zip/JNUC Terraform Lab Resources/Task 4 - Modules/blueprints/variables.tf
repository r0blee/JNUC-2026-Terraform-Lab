variable "attendee_name" {
  type        = string
  description = "Attendee name used as a naming prefix"
}