terraform {
required_providers {
jamfplatform = {
source = "Jamf-Concepts/jamfplatform"
}
}
}

data "jamfplatform_device_groups" "all_managed_clients" {
filter = [
{
selector = "name"
argument = "All Managed Clients"
},
{
join_with = "and"
selector  = "groupType"
argument  = "SMART"
}
]
}


resource "jamfplatform_blueprints_blueprint" "set_and_forget_os_updates" {
name          = "[${var.attendee_name}] Set and Forget OS Updates"
description   = "Managed by Terraform"
deployed      = true
device_groups = data.jamfplatform_device_groups.all_managed_clients.device_groups[*].id

component_blocks = [
{
name = "Software Update"
software_update = {
ignore_major_versions = true
deployment_time       = "17:00"
enforce_after_days    = 7
details_url_value     = "https://support.apple.com/en-us/100100"
}
}
]
}

resource "jamfplatform_blueprints_blueprint" "baseline_restrictions" {
name        = "[${var.attendee_name}] Baseline Restrictions"
description = "Managed by Terraform"
deployed    = true

device_groups = data.jamfplatform_device_groups.all_managed_clients.device_groups[*].id

component_blocks = [
{
name = "Baseline Restrictions"
passcode_policy = {
require_passcode = true
minimum_length   = 6
}
math_settings = {
calculator_scientific_mode_enabled   = true
system_behavior_keyboard_suggestions = true
system_behavior_math_notes           = true
}
},
]
}

resource "jamfplatform_blueprints_blueprint" "software_update_settings" {
name        = "[${var.attendee_name}] Software Update Settings"
description = "Managed by Terraform"
deployed    = true

device_groups = data.jamfplatform_device_groups.all_managed_clients.device_groups[*].id

component_blocks = [
{
name = "Software Update Settings"
software_update_settings = {
allow_standard_user_os_updates           = true
automatic_download                       = "AlwaysOn"
automatic_install_os_updates             = "AlwaysOn"
automatic_install_security_updates       = "AlwaysOn"
beta_program_enrollment                  = "Allowed"
deferral_combined_period_days            = 7
deferral_major_period_days               = 30
deferral_minor_period_days               = 14
deferral_system_period_days              = 3
notifications_enabled                    = true
rapid_security_response_enabled          = true
rapid_security_response_rollback_enabled = false
recommended_cadence                      = "Newest"

beta_offer_programs = [{
token       = "beta-token-1"
description = "iOS 18 Beta Program"
}, {
token       = "beta-token-2"
description = "macOS Sequoia Beta Program"
}]
}
},
]
}