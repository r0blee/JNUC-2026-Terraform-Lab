resource "jamfplatform_pro_account" "auditor" {
  username      = var.attendee_name
  full_name     = var.attendee_name
  email_address = "${replace(trimspace(lower(var.attendee_name)), "/\\s+/", ".")}@jnuc.com"
  access_level  = "Site Access"
  privilege_set = "Auditor"
  site_id = 1	

  # WriteOnly password; bump password_wo_version to rotate.
  password            = var.account_password
  password_wo_version = 1
}