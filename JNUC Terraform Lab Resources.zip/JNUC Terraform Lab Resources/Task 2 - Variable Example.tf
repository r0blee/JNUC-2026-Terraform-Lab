variable "attendee_name" {
  type        = string #string, number etc
  default     = "<DEFAULT_VALUE>" #Sets the default value for this variable.
  description = "This is the name of the attendee performing the JNUC lab tasks." #A description of the variable’s purpose and the value it expects.
}